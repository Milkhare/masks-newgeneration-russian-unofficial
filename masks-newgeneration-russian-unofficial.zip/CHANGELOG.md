#0.1.8
- bug fixes for HCHC Playbooks

#0.1.7
- shift labels macro bug fix

#0.1.6
- bug fix

#0.1.5
- bug fix

#0.1.4
- added playbooks from Halcyon City Herald Collection in compendium HCHC Playbooks

#0.1.3
- validated v9 compatibility

#0.1.2
- first version of revised module
- version numbering aligned with versions on original module
